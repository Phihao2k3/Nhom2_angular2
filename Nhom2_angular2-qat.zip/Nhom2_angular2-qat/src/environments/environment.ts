export const environment = {
  dev: false,
  stage: false,
  production: false,
  apiBaseUrl: 'http://localhost:8000',
};
