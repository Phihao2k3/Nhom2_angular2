import {Component} from "@angular/core";

@Component({
  selector: 'ngx-auth',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class AuthComponent {
  constructor() {}
}
