export interface IRouterConfig {
  pageNotFound: string;
  forbidden: string;
  auth: any;
  pages: string;
}
