export interface IAppConfig {
  module: string;
  apiBaseUrl: string;
  httpStatus: any;
}
