export class ILogin {
  idLogin: string;
  email: string;
  password: string;
  newPassword: string;
  confirmPassword: string;
  verificationCode: string;
}
