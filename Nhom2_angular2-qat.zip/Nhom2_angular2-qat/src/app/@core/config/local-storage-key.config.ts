import {ILocalStorageKeyConfig} from "../interfaces";

export const LOCALSTORAGE_KEY: ILocalStorageKeyConfig = {
  userInfo: 'userInfo',
  token: 'token'
};
