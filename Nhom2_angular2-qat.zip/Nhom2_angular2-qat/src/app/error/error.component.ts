import {Component} from "@angular/core";

@Component({
  selector: 'ngx-error',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ErrorComponent {
  constructor() {}
}
